#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string>
#include <cstring>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

using namespace std;
int main (int argc, char *argv[]){
 
	// situation with wrong input code
	if (argc < 3)
	{
		cout << "Input code has to be: " + string(argv[0]) + "server_IP port_number\n" ;
		exit(0);
	}
	//change portnumber into number
	int port_num = atoi(argv[2]);

	//get server_ip
	struct hostent *server_ptr;
	server_ptr = gethostbyname(argv[1]);
	if (server_ptr == NULL)
	{
		cout << "We cannot find the host.\n";
		exit(0);
	}

	//sd = socket_descriptor
	int sd = socket(AF_INET, SOCK_STREAM, 0);
	if (sd < 0)
	{
		cout << "Wrong socket number.\n";
		exit(0);
	}

	struct sockaddr_in server_addr;

	memset((char *) &server_addr, 0, sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	memmove((char *) &server_addr.sin_addr.s_addr,(char *) server_ptr->h_addr, server_ptr->h_length);
	server_addr.sin_port = htons(port_num);

	if (connect(sd,(struct sockaddr *) &server_addr, sizeof(server_addr)) < 0)
	{
		cout << "Connection is not successful.\n";
		exit(0);
	}

	string input;

	char responce_buffer[1024];
	memset(responce_buffer, 0, 1024);

	recv(sd,(char *) &responce_buffer, 1023, 0);
	cout << responce_buffer << endl;

	bool login = 1;
	bool regi = 1;
	string register_name, login_name, login_portNum;

	while(regi) {
		cout << "Enter 1 for Register, 2 for Login: ";
		cin >> input;

		if (input == "1")
		{
			cout << "Enter the name to register: ";
			cin >> register_name;
			input = "REGISTER#" + register_name; 
		}
		else if (input == "2")
		{
			cout << "Enter your name: ";
			cin >> login_name;
			cout << "Enter port number: ";
			cin >> login_portNum;
			input = login_name + "#" + login_portNum;
		}		
		else
			cout << "Wrong input";	

		send(sd, input.c_str(), input.length(), 0);
		memset(responce_buffer, 0, 1024);
		recv(sd,(char *) &responce_buffer, 1023, 0);
		cout << responce_buffer <<endl;

		if (responce_buffer[0] != '1' && responce_buffer[0] != '2')
			regi = 0;
	}
	cout << "Login Successfully\n";

	while(login) {
		
		cout << "Enter 1 to ask for the latest list, 8 to exit: ";
		cin >> input;

		if (input == "1")
			input = "List";
		else if (input == "8")
		{
			input = "Exit";
			login = 0;
		}
		else
			cout << "Wrong input";
	
		send(sd, input.c_str(), input.length(), 0);
		memset(responce_buffer, 0, 1024);
		recv(sd,(char *) &responce_buffer, 1023, 0);
		cout << responce_buffer <<endl;


	}
	
	close(sd);
	return 0;

}